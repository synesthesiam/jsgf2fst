.. _jsgf-errors:

:py:mod:`errors` --- Error classes module
===============================================================

.. automodule:: jsgf.errors

=======
Classes
=======

.. autoclass:: CompilationError
.. autoclass:: GrammarError
.. autoclass:: ExpansionError
.. autoclass:: MatchError
