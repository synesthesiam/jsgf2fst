.. _jsgf-grammars:

:py:mod:`grammars` --- Grammar classes module
=================================================

.. automodule:: jsgf.grammars


=======
Classes
=======

.. autoclass:: Import
   :members:
.. autoclass:: Grammar
   :members:
.. autoclass:: RootGrammar
   :members: compile
